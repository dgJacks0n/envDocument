---
title: test_envDocument
author: Donald Jackson (donald.jackson@bms.com)
description: test suite for envDocument package
---
Note: I'm not sure how to run a true regression test on this package since its
purpose is to print out a lot of machine-specific info.  For now just make
sure it outupts the appropriate sections (system, Rversion and included package envDocument)


```r
# comment out for build/reload, turn back on for development
library(envDocument) # 

info <- env_doc()

knitr::opts_chunk$set(results="asis")

print( knitr::kable(info) )
```



|Section  |Name           |Value                                      |
|:--------|:--------------|:------------------------------------------|
|System   |sysname        |Windows                                    |
|System   |release        |7                                          |
|System   |version        |build 7601, Service Pack 1                 |
|System   |nodename       |R9HFB71                                    |
|System   |machine        |x86                                        |
|System   |login          |jacksod                                    |
|System   |user           |jacksod                                    |
|System   |effective_user |jacksod                                    |
|System   |Directory      |C:/Users/jacksod/Documents/R/envDocument/R |
|R        |Version        |R version 3.1.3 (2015-03-09)               |
|Packages |envDocument    |2.1.1 BMS BMS 2015-10-24                   |
|Script   |Path           |~/R/envDocument/R/test_envDocument.R       |
|Script   |Modified       |2015-10-26 08:05:04                        |

```r
# 
# envinfo <- env_doc(output="return")
 # env_doc(output="table") 
# 
# #  path <- get_scriptpath()
#  info <- get_scriptinfo()
```

