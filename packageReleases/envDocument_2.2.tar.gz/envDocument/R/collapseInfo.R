#' Collapse list of enviornment information into a single data frme
#' 
collapseInfo <- function(info_list = list()) {
  tag_list <- lapply(names(info_list), tagSection, info_list)
  return(tag_list)
}


tagSection <- function(section_name, info_list) {
  info_list[[section_name]]$Section <- section_name
  return(info_list)
}
