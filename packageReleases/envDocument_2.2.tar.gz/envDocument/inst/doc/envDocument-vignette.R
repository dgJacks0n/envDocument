## ---- echo = TRUE, eval = FALSE------------------------------------------
#  library(envDocument)
#  library(knitr)
#  
#  
#  kable(env_doc()) # with git2r installed
#  kable(env_doc(git = FALSE)) # without git2r

## ----table, echo = TRUE, eval = FALSE------------------------------------
#  env_doc("table")

