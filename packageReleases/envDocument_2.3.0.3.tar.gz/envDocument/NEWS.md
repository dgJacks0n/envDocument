# NEWS

# envDocument 2.3.0.2
Development release implementing Domino environment information.  

# envDocument 2.3.0.1
An interim development release with minor changes and bugfixes

+ Modified Author section in DESCRIPTION file in an effort to get better formatting.
+ Implemented `try()` calls to handle missing file/package errors more gracefully and consistently.

# envDocument 2.3.0
This is the first CRAN submission for package envDocument.  The version number for this first submission is 2.3.0 for consistency with previous internal versions of this package.
