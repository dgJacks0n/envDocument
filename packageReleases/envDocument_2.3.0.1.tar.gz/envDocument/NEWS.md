# NEWS

This is the first CRAN submission for package envDocument.

The version number for this first submission is 2.3.0 for consistency with previous internal versions of this package.
